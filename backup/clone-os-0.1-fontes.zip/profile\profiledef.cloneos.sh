
# --- Clone OS (anexado ao profiledef.sh do releng pelo build.sh) ---
iso_name="cloneos"
iso_label="CLONEOS_$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m)"
iso_publisher="Clone OS"
iso_application="Clone OS Live"
iso_version="0.1-alpha.$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m%d)"
# zstd gera uma ISO um pouco maior que xz, mas o build fica bem mais rápido.
airootfs_image_tool_options=('-comp' 'zstd' '-Xcompression-level' '15' '-b' '1M')
file_permissions+=(
  ["/etc/sudoers.d"]="0:0:750"
  ["/etc/sudoers.d/10-wheel"]="0:0:440"
  ["/etc/sudoers.d/20-cloneos-live"]="0:0:440"
  ["/usr/local/bin/clone-ai"]="0:0:755"
  ["/usr/local/bin/clone-install"]="0:0:755"
  ["/usr/local/bin/clone-welcome"]="0:0:755"
  ["/usr/local/bin/clonectl"]="0:0:755"
  ["/usr/local/bin/cloneos-brand"]="0:0:755"
  ["/usr/local/bin/cloneos-build-customize"]="0:0:755"
  ["/usr/local/bin/cloneos-firstrun"]="0:0:755"
)
