# Clone OS (alpha 0.1)

Um Arch Linux com KDE Plasma 6 e o Claude integrado ao sistema.

- **Base:** perfil oficial `releng` do Arch (o mesmo da ISO oficial) + pacotes dos repositórios oficiais.
- **Interface:** KDE Plasma 6 (Wayland, com sessão X11 de reserva), tema próprio escuro/claro, 4 papéis de parede.
- **Claude:** Claude Code como agente do sistema, login pela conta Claude no Chromium, acesso só às pastas liberadas.
- **Tamanho:** ISO de uns 3 a 4 GB; instalado, algo entre 10 e 15 GB. A meta de 40 GB tem folga (os números exatos saem do primeiro build).

## Como funciona o primeiro uso

1. A ISO inicia direto na área de trabalho (modo live, usuário `clone`, sem senha).
2. O **Clone Welcome** abre sozinho:
   1. **Bem-vindo**: no modo live mostra o botão *Instalar Clone OS*.
   2. **Conectar o Claude**: instala o Claude Code (instalador oficial `claude.ai/install.sh`) e faz o
      login com a sua conta Claude. O login abre no Chromium e o status muda sozinho para *Conectado*.
      Também tem atalhos para o claude.ai e para a extensão Claude in Chrome.
   3. **Permissões**: você marca as pastas que o Claude pode acessar e escolhe como ele age
      (perguntar antes, editar direto ou só planejar). Chaves SSH/GPG, senhas do navegador,
      KWallet e as credenciais do Claude ficam sempre bloqueadas.
   4. **Aparência**: tema, cor de destaque e papel de parede, aplicados na hora.
   5. **Pronto**: atalho **Meta + C** (tecla Windows + C) abre o Claude de qualquer lugar.
3. O instalador (`clone-install`) copia o sistema para o disco sem precisar de internet, cria o seu
   usuário com senha e instala o GRUB (UEFI ou BIOS). No primeiro login o Clone Welcome aparece de novo.

### Como o Claude se integra

| Peça | O que faz |
|---|---|
| `clone-ai` (atalho Meta+C, menu "Claude") | Abre o Claude Code em `~/Clone`, com as pastas liberadas. Na primeira vez, instala e faz o login. |
| `~/.claude/settings.json` | Onde o Clone Welcome grava as pastas liberadas (`additionalDirectories`), o modo de permissão e os bloqueios. |
| `~/Clone/CLAUDE.md` | Explica ao Claude o sistema: `clonectl`, LibreOffice headless, `openpyxl`/`pandas`, `kdialog`… |
| `clonectl` | Muda tema, cor e papel de parede. O Claude usa o mesmo comando quando você pede ("deixa o tema claro"). |
| Claude (Web) | O claude.ai como aplicativo, e a página inicial do Chromium. |

> O Claude Code exige um plano Claude Pro, Max, Team ou Enterprise, ou uma chave da API.

## Gerar a ISO

### No Windows (WSL)

1. Uma vez só, no PowerShell **como administrador**: `wsl --install -d archlinux` (reinicie se pedir).
2. Nesta pasta:

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

A ISO sai em `out\cloneos-0.1-alpha.AAAAMMDD-x86_64.iso`. O build baixa uns 3 GB de pacotes e usa
uns 20 GB de espaço temporário no WSL.

### No Arch Linux

```bash
sudo ./build.sh
```

## Rodar numa VM

Recomendado: **4 CPUs, 8 GB de RAM, disco de 40 GB, UEFI com Secure Boot desligado.**

- **Hyper-V** (já vem no Windows 11 Pro; é a melhor opção se o WSL2 estiver instalado):
  ative o recurso Hyper-V e rode, como administrador, `.\tools\new-vm-hyperv.ps1`.
- **VirtualBox 7:** `.\tools\new-vm-virtualbox.ps1`. Com o WSL2 instalado, o VirtualBox funciona, mas mais devagar.

Os dois scripts pegam a ISO mais recente de `out\`, criam a VM e ligam.

Se a sessão Wayland falhar na VM, saia e escolha **Plasma (X11)** na tela de login.

## Estrutura

```
build.ps1 / build.sh        geram a ISO (releng oficial + camada do Clone OS)
profile/
  packages.cloneos          pacotes somados aos do releng
  packages.remove           pacotes do releng que saem
  profiledef.cloneos.sh     nome, versão, compressão e permissões da ISO
  syslinux/splash.png       fundo do menu de boot BIOS
  airootfs/                 arquivos copiados para o sistema
    usr/local/bin/          clone-ai, clonectl, clone-install, clone-welcome, cloneos-*
    usr/share/cloneos/      logo, CLAUDE.md, app Clone Welcome (Python + PySide6)
    usr/share/wallpapers/   papéis de parede (pacotes do KDE)
    usr/share/color-schemes/, usr/share/icons/   temas escuro/claro
    etc/                    SDDM, sudo, teclado ABNT2, Chromium, autostart, hooks do pacman
tools/
  build_assets.py           gera papéis de parede, ícones, esquemas de cor e o splash
  new-vm-*.ps1              criam a VM
```

## Desenvolvimento no Windows

```powershell
# regenerar arte e temas depois de mudar cores/logo
uv run --no-project --with pyside6 python tools/build_assets.py

# abrir o Clone Welcome em modo demonstração (não executa nada no sistema)
uv run --no-project --with pyside6 python profile/airootfs/usr/share/cloneos/welcome/clone_welcome.py --live
```

## Limitações desta alpha

- O instalador é de terminal e usa o disco inteiro (sem dual boot, sem criptografia).
- Idioma pt-BR e fuso America/Sao_Paulo fixos na ISO; o teclado é escolhido na instalação.
- E-mail e planilhas funcionam via Thunderbird/LibreOffice e arquivos locais; conectores diretos
  (Gmail, Google Drive etc.) ainda não fazem parte do assistente.
- Sem Secure Boot e sem Plymouth (tela de boot animada).
- Atualizar o pacote `filesystem` restaura a identidade do Clone OS automaticamente (hook do pacman).
