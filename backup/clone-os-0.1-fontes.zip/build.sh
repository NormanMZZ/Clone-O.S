#!/usr/bin/env bash
# Gera a ISO do Clone OS. Precisa rodar no Arch Linux (máquina, VM ou WSL).
#
# O perfil é montado em cima do "releng", o perfil oficial da ISO do Arch
# instalado pelo pacote archiso: assim o boot (BIOS e UEFI) é sempre o da
# versão do archiso instalada, e o Clone OS só acrescenta o que é dele.
#
#   ./build.sh                          ISO em ./out
#   CLONEOS_OUT=/outro/lugar ./build.sh
set -euo pipefail

here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
work="${CLONEOS_WORK:-/var/tmp/cloneos-build}"
out="${CLONEOS_OUT:-$here/out}"
releng=/usr/share/archiso/configs/releng

if (( EUID != 0 )); then
    exec sudo --preserve-env=CLONEOS_WORK,CLONEOS_OUT "$0" "$@"
fi

[[ -f /etc/arch-release ]] || { echo "Este build precisa rodar no Arch Linux." >&2; exit 1; }

if ! command -v mkarchiso >/dev/null; then
    echo "==> Instalando o archiso"
    pacman -Syu --needed --noconfirm archiso
fi

echo "==> Preparando o perfil em $work"
profile="$work/profile"
rm -rf -- "$work"
mkdir -p -- "$profile" "$out"
cp -a -- "$releng/." "$profile/"

# Partes do releng pensadas para a ISO de instalação em modo texto:
# login automático do root no tty1, cloud-init, e rede via iwd/systemd-networkd
# (o Clone OS usa o NetworkManager, que conflita com eles).
rm -rf -- "$profile/airootfs/etc/systemd/system/getty@tty1.service.d" \
          "$profile/airootfs/etc/systemd/system/cloud-init.target.wants"
rm -f -- "$profile/airootfs/etc/motd" \
         "$profile/airootfs/etc/systemd/system/multi-user.target.wants/"{iwd,systemd-networkd,sshd}.service \
         "$profile/airootfs/etc/systemd/system/sockets.target.wants/systemd-networkd.socket" \
         "$profile/airootfs/etc/systemd/system/network-online.target.wants/systemd-networkd-wait-online.service" \
         "$profile/airootfs/etc/systemd/system/dbus-org.freedesktop.network1.service"

echo "==> Aplicando os arquivos do Clone OS"
cp -a -- "$here/profile/airootfs/." "$profile/airootfs/"
cp -- "$here/profile/syslinux/splash.png" "$profile/syslinux/splash.png"
cat -- "$here/profile/profiledef.cloneos.sh" >>"$profile/profiledef.sh"

# Arquivos editados no Windows podem vir com CRLF, o que quebra scripts e configs.
# (grep sai com 1 quando não acha nada, o que aqui é o normal.)
{ grep -rlI $'\r' "$profile" || true; } | xargs -r sed -i 's/\r$//'

strip() { sed -e 's/#.*//' -e 's/[[:space:]]*$//' -e '/^$/d' "$1"; }
{
    grep -vxF -f <(strip "$here/profile/packages.remove") "$releng/packages.x86_64" || true
    strip "$here/profile/packages.cloneos"
} | sort -u >"$profile/packages.x86_64"
echo "    $(wc -l <"$profile/packages.x86_64") pacotes"

# Menus de boot com o nome do Clone OS
{ grep -rlI 'Arch Linux' "$profile/efiboot" "$profile/grub" "$profile/syslinux" || true; } | xargs -r sed -i \
    -e 's/Arch Linux install medium/Clone OS (live)/g' \
    -e 's/install Arch Linux/install Clone OS/g' \
    -e 's/Arch Linux/Clone OS/g'

echo "==> Gerando a ISO (demora: baixa ~3 GB de pacotes)"
mkarchiso -v -r -w "$work/work" -o "$out" "$profile"

if [[ -n "${SUDO_USER:-}" ]]; then
    chown "$SUDO_USER:" "$out"/*.iso 2>/dev/null || true
fi
echo
echo "==> Pronto:"
ls -lh "$out"/*.iso
