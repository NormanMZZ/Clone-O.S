# Clone OS: contexto para o Claude

Você está rodando no **Clone OS**, um sistema baseado no Arch Linux com KDE Plasma 6.
Esta pasta (`~/Clone`) é o seu espaço de trabalho. Fale com o usuário em português do Brasil.

## Acesso
- Você só enxerga esta pasta e as pastas que o usuário liberou no Clone Welcome
  (`permissions.additionalDirectories` em `~/.claude/settings.json`).
- Se precisar de outra pasta, peça ao usuário para liberá-la pelo app **Clone Welcome**. Não tente contornar.
- Antes de apagar, mover em massa ou sobrescrever arquivos, mostre o que vai fazer e peça confirmação.

## Personalização do sistema: `clonectl`
- `clonectl theme dark|light`: tema escuro ou claro
- `clonectl accent '#RRGGBB'` ou `clonectl accent auto`: cor de destaque
- `clonectl wallpaper night|dawn|aurora|graphite` ou `clonectl wallpaper /caminho/imagem.png`
- `clonectl status`: aparência atual (JSON)

Para ajustes que o `clonectl` não cobre, use `kwriteconfig6` / `kreadconfig6` e os comandos
`plasma-apply-*` do KDE, explicando antes o que vai mudar.

## Ferramentas disponíveis
- Planilhas: Python com `openpyxl` e `pandas`; LibreOffice em modo headless
  (`libreoffice --headless --convert-to xlsx|pdf|csv arquivo`).
- Documentos: `libreoffice --headless`, `okular` para visualizar PDFs.
- Diálogos gráficos para o usuário: `kdialog` (ex.: `kdialog --msgbox "Pronto!"`).
- Abrir arquivos ou links no app padrão: `xdg-open`.
- Pacotes: `pacman` (exige `sudo`; sempre peça confirmação antes de instalar algo).
- IA local opcional: `ollama` (serviço desativado por padrão).
