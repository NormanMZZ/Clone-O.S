"""Gera a arte e os temas do Clone OS dentro de profile/.

Rode sempre que mudar cores, logo ou papéis de parede:
    uv run --with pyside6 python tools/build_assets.py
"""

from __future__ import annotations

import json
import math
import random
import shutil
import sys
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QColor,
    QFont,
    QGuiApplication,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QRadialGradient,
)
from PySide6.QtSvg import QSvgRenderer

REPO = Path(__file__).resolve().parents[1]
PROFILE = REPO / "profile"
AIROOTFS = PROFILE / "airootfs"
LOGO = AIROOTFS / "usr/share/cloneos/logo.svg"

BLUE = "#1793D1"
CLAY = "#D97757"

# --------------------------------------------------------------------------
# Esquemas de cor do KDE
# --------------------------------------------------------------------------

SCHEMES = {
    "CloneOSDark": {
        "name": "Clone OS Escuro",
        "fg": {
            "Normal": "#E6E9EF", "Inactive": "#9AA3B2", "Active": "#43B6EE",
            "Link": "#43B6EE", "Visited": "#B48CF2", "Negative": "#F0616D",
            "Neutral": "#F2A65A", "Positive": "#3CCB8A",
        },
        "bg": {
            "Window": ("#1B1F2A", "#222734"),
            "View": ("#141720", "#1A1E29"),
            "Button": ("#262C3A", "#2D3444"),
            "Header": ("#151923", "#1B1F2A"),
            "Tooltip": ("#1B1F2A", "#222734"),
            "Complementary": ("#10131A", "#151923"),
            "Selection": (BLUE, "#126E9C"),
        },
        "header_inactive": ("#1B1F2A", "#222734"),
        "wm": {"active": "#151923", "inactive": "#1B1F2A"},
    },
    "CloneOSLight": {
        "name": "Clone OS Claro",
        "fg": {
            "Normal": "#1B1F2A", "Inactive": "#5B6576", "Active": BLUE,
            "Link": "#0F7BB5", "Visited": "#7C4DCC", "Negative": "#D6334A",
            "Neutral": "#C26A12", "Positive": "#1E9E63",
        },
        "bg": {
            "Window": ("#EEF1F5", "#E6EAF0"),
            "View": ("#FFFFFF", "#F5F7FA"),
            "Button": ("#F7F8FA", "#E3E8EF"),
            "Header": ("#E3E8EF", "#EEF1F5"),
            "Tooltip": ("#F7F8FA", "#E3E8EF"),
            "Complementary": ("#1B1F2A", "#222734"),
            "Selection": (BLUE, "#126E9C"),
        },
        "header_inactive": ("#EEF1F5", "#E3E8EF"),
        "wm": {"active": "#E3E8EF", "inactive": "#EEF1F5"},
    },
}

COLOR_EFFECTS = """[ColorEffects:Disabled]
Color=56,56,56
ColorAmount=0
ColorEffect=0
ContrastAmount=0.65
ContrastEffect=1
IntensityAmount=0.1
IntensityEffect=2

[ColorEffects:Inactive]
ChangeSelectionColor=true
Color=112,111,110
ColorAmount=0.025
ColorEffect=2
ContrastAmount=0.1
ContrastEffect=2
Enable=false
IntensityAmount=0
IntensityEffect=0
"""


def rgb(hex_color: str) -> str:
    c = QColor(hex_color)
    return f"{c.red()},{c.green()},{c.blue()}"


def color_group(title: str, bg: tuple[str, str], fg: dict[str, str], selection: bool = False) -> str:
    fg_normal = "#FFFFFF" if selection else fg["Normal"]
    fg_inactive = "#D6ECF8" if selection else fg["Inactive"]
    lines = [
        f"[{title}]",
        f"BackgroundAlternate={rgb(bg[1])}",
        f"BackgroundNormal={rgb(bg[0])}",
        f"DecorationFocus={rgb(BLUE)}",
        f"DecorationHover={rgb('#43B6EE')}",
        f"ForegroundActive={rgb(fg['Active'])}",
        f"ForegroundInactive={rgb(fg_inactive)}",
        f"ForegroundLink={rgb(fg['Link'])}",
        f"ForegroundNegative={rgb(fg['Negative'])}",
        f"ForegroundNeutral={rgb(fg['Neutral'])}",
        f"ForegroundNormal={rgb(fg_normal)}",
        f"ForegroundPositive={rgb(fg['Positive'])}",
        f"ForegroundVisited={rgb(fg['Visited'])}",
    ]
    return "\n".join(lines) + "\n"


def scheme_body(key: str) -> str:
    s = SCHEMES[key]
    fg = s["fg"]
    parts = [COLOR_EFFECTS]
    for group, bg in s["bg"].items():
        if group == "Complementary":
            comp_fg = dict(fg, Normal="#E6E9EF", Inactive="#9AA3B2")
            parts.append(color_group("Colors:Complementary", bg, comp_fg))
        elif group == "Selection":
            parts.append(color_group("Colors:Selection", bg, fg, selection=True))
        else:
            parts.append(color_group(f"Colors:{group}", bg, fg))
            if group == "Header":
                parts.append(color_group("Colors:Header][Inactive", s["header_inactive"], fg))
    wm = s["wm"]
    parts.append(
        "[WM]\n"
        f"activeBackground={rgb(wm['active'])}\n"
        f"activeBlend={rgb(fg['Normal'])}\n"
        f"activeForeground={rgb(fg['Normal'])}\n"
        f"inactiveBackground={rgb(wm['inactive'])}\n"
        f"inactiveBlend={rgb(fg['Inactive'])}\n"
        f"inactiveForeground={rgb(fg['Inactive'])}\n"
    )
    return "\n".join(parts)


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def build_color_schemes() -> None:
    for key, s in SCHEMES.items():
        text = scheme_body(key) + f"\n[General]\nColorScheme={key}\nName={s['name']}\nshadeSortColumn=true\n\n[KDE]\ncontrast=4\n"
        write(AIROOTFS / f"usr/share/color-schemes/{key}.colors", text)

    # Padrões do sistema para todo usuário novo (antes mesmo do primeiro login terminar).
    kdeglobals = (
        scheme_body("CloneOSDark")
        + "\n[General]\nColorScheme=CloneOSDark\nBrowserApplication=chromium.desktop\n"
        + "\n[Icons]\nTheme=CloneOS-Dark\n"
        + "\n[KDE]\nLookAndFeelPackage=org.kde.breezedark.desktop\ncontrast=4\n"
    )
    write(AIROOTFS / "etc/xdg/kdeglobals", kdeglobals)


# --------------------------------------------------------------------------
# Ícones
# --------------------------------------------------------------------------

ICON_AI = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#E88F6C"/>
      <stop offset="1" stop-color="#B9532F"/>
    </linearGradient>
  </defs>
  <rect x="8" y="8" width="112" height="112" rx="28" fill="url(#g)"/>
  <path d="M58 26 C60 48 68 56 90 58 C68 60 60 68 58 90 C56 68 48 60 26 58 C48 56 56 48 58 26 Z" fill="#FFFFFF"/>
  <path d="M92 74 C93 83 97 87 106 88 C97 89 93 93 92 102 C91 93 87 89 78 88 C87 87 91 83 92 74 Z" fill="#FFFFFF" fill-opacity="0.85"/>
</svg>
"""

ICON_AI_WEB = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <rect x="8" y="8" width="112" height="112" rx="28" fill="#1B2130"/>
  <circle cx="64" cy="64" r="38" fill="none" stroke="#43B6EE" stroke-opacity="0.45" stroke-width="5"/>
  <path d="M64 30 C66 52 74 60 96 62 C74 64 66 72 64 94 C62 72 54 64 32 62 C54 60 62 52 64 30 Z" fill="#D97757"/>
</svg>
"""

ICON_INSTALL = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#3FB0EA"/>
      <stop offset="1" stop-color="#0F6E9F"/>
    </linearGradient>
  </defs>
  <rect x="8" y="8" width="112" height="112" rx="28" fill="url(#g)"/>
  <path d="M64 30 V80 M44 61 L64 81 L84 61" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M34 84 V96 H94 V84" fill="none" stroke="#FFFFFF" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
"""

START_HERE_NAMES = [
    "start-here", "start-here-symbolic", "start-here-kde", "start-here-kde-symbolic",
    "start-here-kde-plasma", "start-here-kde-plasma-symbolic", "distributor-logo",
    "distributor-logo-symbolic",
]


def build_icons() -> None:
    logo = LOGO.read_text(encoding="utf-8")
    hicolor = AIROOTFS / "usr/share/icons/hicolor/scalable/apps"
    write(hicolor / "cloneos.svg", logo)
    write(hicolor / "cloneos-ai.svg", ICON_AI)
    write(hicolor / "cloneos-ai-web.svg", ICON_AI_WEB)
    write(hicolor / "cloneos-install.svg", ICON_INSTALL)

    for variant, parent, label in (("Dark", "breeze-dark", "escuro"), ("Light", "breeze", "claro")):
        theme = AIROOTFS / f"usr/share/icons/CloneOS-{variant}"
        if theme.exists():
            shutil.rmtree(theme)
        write(
            theme / "index.theme",
            f"[Icon Theme]\nName=Clone OS ({label})\nComment=Breeze com a marca do Clone OS\n"
            f"Inherits={parent},hicolor\nDirectories=scalable/places\n\n"
            "[scalable/places]\nSize=64\nMinSize=8\nMaxSize=512\nType=Scalable\nContext=Places\n",
        )
        for name in START_HERE_NAMES:
            write(theme / f"scalable/places/{name}.svg", logo)


# --------------------------------------------------------------------------
# Papéis de parede e tela de boot
# --------------------------------------------------------------------------

def chevron(cx: float, top: float, h: float) -> QPainterPath:
    """A mesma forma do logo: um pico com recorte, altura h."""
    w = h * 40 / 96
    notch_w = h * 16.8 / 96
    notch_y = top + h * 56 / 96
    path = QPainterPath(QPointF(cx, top))
    for x, y in ((cx + w, top + h), (cx + notch_w, top + h), (cx, notch_y), (cx - notch_w, top + h), (cx - w, top + h)):
        path.lineTo(x, y)
    path.closeSubpath()
    return path


def triangle(cx: float, top: float, h: float) -> QPainterPath:
    w = h * 40 / 96
    path = QPainterPath(QPointF(cx, top))
    path.lineTo(cx + w, top + h)
    path.lineTo(cx - w, top + h)
    path.closeSubpath()
    return path


def with_alpha(hex_color: str, alpha: int) -> QColor:
    c = QColor(hex_color)
    c.setAlpha(max(0, min(255, alpha)))
    return c


def noise_tile(strength: int) -> QImage:
    rnd = random.Random(7)
    tile = QImage(192, 192, QImage.Format_ARGB32)
    for y in range(192):
        for x in range(192):
            v = 255 if rnd.random() > 0.5 else 0
            tile.setPixelColor(x, y, QColor(v, v, v, rnd.randint(0, strength)))
    return tile


WALLPAPERS = {
    "Night": {
        "title": "Clone Noite",
        "bg": ("#070B16", "#12203B"),
        "glows": [((0.76, 0.34), 0.55, BLUE, 80), ((0.60, 0.86), 0.42, CLAY, 55)],
        "echo": (BLUE, CLAY), "echo_alpha": 70,
        "logo": (("#43B6EE", "#1273A8"), ("#F29D7B", "#C65B39")),
        "stars": True,
    },
    "Dawn": {
        "title": "Clone Amanhecer",
        "bg": ("#FBF3EC", "#EDB999"),
        "glows": [((0.30, 0.20), 0.60, "#FFFFFF", 150), ((0.78, 0.70), 0.45, CLAY, 70)],
        "echo": ("#B45A38", "#1B6F9E"), "echo_alpha": 60,
        "logo": (("#43B6EE", "#1273A8"), ("#F29D7B", "#C65B39")),
        "stars": False,
    },
    "Aurora": {
        "title": "Clone Aurora",
        "bg": ("#04161A", "#0B2F2C"),
        "glows": [((0.70, 0.25), 0.55, "#10B981", 75), ((0.35, 0.90), 0.45, BLUE, 60)],
        "echo": ("#34D399", "#43B6EE"), "echo_alpha": 65,
        "logo": (("#6EE7B7", "#0E8F6A"), ("#7DD3FC", "#1273A8")),
        "stars": True,
    },
    "Graphite": {
        "title": "Clone Grafite",
        "bg": ("#121317", "#24262D"),
        "glows": [((0.72, 0.40), 0.55, "#8B93A7", 45)],
        "echo": ("#9AA3B2", "#6B7385"), "echo_alpha": 55,
        "logo": (("#E6E9EF", "#9AA3B2"), ("#9AA3B2", "#5B6576")),
        "stars": False,
    },
}


def paint_background(p: QPainter, w: int, h: int, spec: dict, noise: QImage) -> None:
    grad = QLinearGradient(0, 0, w, h)
    grad.setColorAt(0, QColor(spec["bg"][0]))
    grad.setColorAt(1, QColor(spec["bg"][1]))
    p.fillRect(0, 0, w, h, grad)

    for (fx, fy), radius, color, alpha in spec["glows"]:
        rg = QRadialGradient(QPointF(fx * w, fy * h), radius * w)
        rg.setColorAt(0, with_alpha(color, alpha))
        rg.setColorAt(1, with_alpha(color, 0))
        p.fillRect(0, 0, w, h, rg)

    if spec["stars"]:
        rnd = random.Random(42)
        p.setPen(Qt.NoPen)
        for _ in range(int(w * h / 9000)):
            x, y = rnd.random() * w, rnd.random() * h * 0.75
            r = rnd.random() * 1.6 + 0.3
            p.setBrush(QColor(255, 255, 255, rnd.randint(20, 110)))
            p.drawEllipse(QPointF(x, y), r, r)

    p.drawTiledPixmap(0, 0, w, h, _pixmap(noise))


def _pixmap(img: QImage):
    from PySide6.QtGui import QPixmap
    return QPixmap.fromImage(img)


def paint_logo(p: QPainter, cx: float, top: float, h: float, colors, with_echoes: dict | None = None) -> None:
    back = (cx - 12 / 96 * h, top)
    front = (cx + 12 / 96 * h, top + 10 / 96 * h)

    if with_echoes:
        for i in range(1, 16):
            k = 1 + i * 0.16
            fade = int(with_echoes["alpha"] * (1 - i / 16) ** 1.3)
            for (x, y), color in ((back, with_echoes["colors"][0]), (front, with_echoes["colors"][1])):
                hh = h * k
                p.setPen(QPen(with_alpha(color, fade), max(1.5, h / 260), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                p.drawPath(triangle(x, y + (h - hh) * 0.62, hh))

    p.setPen(Qt.NoPen)
    for (x, y), (c1, c2) in ((back, colors[0]), (front, colors[1])):
        g = QLinearGradient(0, y, 0, y + h)
        g.setColorAt(0, QColor(c1))
        g.setColorAt(1, QColor(c2))
        p.setBrush(g)
        p.drawPath(chevron(x, y, h))


def build_wallpapers() -> None:
    noise = noise_tile(9)
    w, h = 2560, 1440
    for key, spec in WALLPAPERS.items():
        base = AIROOTFS / f"usr/share/wallpapers/CloneOS-{key}"
        if base.exists():
            shutil.rmtree(base)
        img = QImage(w, h, QImage.Format_RGB32)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        paint_background(p, w, h, spec, noise)
        paint_logo(
            p, cx=w * 0.70, top=h * 0.30, h=h * 0.40, colors=spec["logo"],
            with_echoes={"colors": spec["echo"], "alpha": spec["echo_alpha"]},
        )
        p.end()
        out = base / "contents/images/2560x1440.png"
        out.parent.mkdir(parents=True, exist_ok=True)
        img.save(str(out), "PNG")
        img.scaled(640, 360, Qt.IgnoreAspectRatio, Qt.SmoothTransformation).save(str(base / "contents/screenshot.png"), "PNG")
        write(
            base / "metadata.json",
            json.dumps(
                {"KPlugin": {"Authors": [{"Name": "Clone OS"}], "Id": f"CloneOS-{key}",
                             "License": "CC-BY-SA-4.0", "Name": spec["title"]}},
                indent=4, ensure_ascii=False,
            ) + "\n",
        )
        print(f"  papel de parede: {out.relative_to(REPO)} ({out.stat().st_size // 1024} KB)")


def build_splash() -> None:
    """Fundo do menu de boot BIOS (syslinux exige 640x480)."""
    w, h = 640, 480
    spec = WALLPAPERS["Night"]
    img = QImage(w, h, QImage.Format_RGB32)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    paint_background(p, w, h, dict(spec, stars=False), noise_tile(0))
    paint_logo(p, cx=236, top=38, h=78, colors=spec["logo"])
    p.setPen(QColor("#E6E9EF"))
    font = QFont("Segoe UI", 30)
    font.setBold(True)
    p.setFont(font)
    p.drawText(QRectF(290, 44, 300, 50), Qt.AlignLeft | Qt.AlignVCenter, "Clone OS")
    font = QFont("Segoe UI", 12)
    p.setFont(font)
    p.setPen(QColor("#9AA3B2"))
    p.drawText(QRectF(292, 90, 300, 26), Qt.AlignLeft | Qt.AlignVCenter, "alpha · baseado no Arch Linux")
    p.end()
    out = PROFILE / "syslinux/splash.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(str(out), "PNG")


def render_logo_png(size: int, out: Path) -> None:
    img = QImage(size, size, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    QSvgRenderer(str(LOGO)).render(p)
    p.end()
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(str(out), "PNG")


def main() -> None:
    app = QGuiApplication(sys.argv)  # noqa: F841 — necessário para fontes e SVG
    print("Gerando esquemas de cor...")
    build_color_schemes()
    print("Gerando ícones...")
    build_icons()
    render_logo_png(256, AIROOTFS / "usr/share/cloneos/logo-256.png")
    print("Gerando papéis de parede...")
    build_wallpapers()
    print("Gerando tela de boot...")
    build_splash()
    print("Pronto.")


if __name__ == "__main__":
    main()
